import random

def generate_split(dataset, base="splits"):
    # test dataset will not be released until week 10
    pass